import collections


def obrnutaRecenica():
    recenica = input("Unesite recenicu ").split()

    j = 0
    konacnarecenica = []

    BrojacRijeci = len(recenica)
    print(recenica)
    print(BrojacRijeci)

    d = collections.OrderedDict()
    d2 = collections.OrderedDict()

    for i in range(0, BrojacRijeci):
        d[i] = recenica[i]

    for i in range(BrojacRijeci-1, -1, -1):
        d2[j] = d[i]
        j += 1

    print(d)

    # ispis drugog rijecnika s obrnutim redoslijedom rijeci
    print(d2)

    # Ispisivanje valuesa rjecnika u listu
    for value in d2.values():
        temp = [value]
        konacnarecenica.append(temp)

    # Ipsis liste
    print(konacnarecenica)

    # ispis clanova liste
    for x in range(0, len(konacnarecenica)):
        print(konacnarecenica[x], end="")


obrnutaRecenica()
