import collections


def brojanjeRijeci():
    f = open("rijeci.txt", "r")
    temp = 0
    d = dict()

    for line in f:
        string = line.split()

    print("\n")
    print(string)

    for i in range(0, len(string)):
        if(i == 0):
            d[string[i]] = 1
            continue
        for j in range(0, i):
            if(string[i] == string[j]):
                d[string[j]] += 1
                break
        else:
            d[string[i]] = 1

    print(d)

    print("\n")

    f.close()


brojanjeRijeci()
